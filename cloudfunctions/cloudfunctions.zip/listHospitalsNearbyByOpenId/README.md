# listHospitalsNearbyByOpenId

**职责**：<TODO — 从以下页面引用而来，完善后作为契约基准>

## 入参（data）
<!--doc:keep:request-->
示例请求体（JSON），必要字段请用注释说明
<!--/doc:keep:request-->

## 出参（result）
<!--doc:keep:response-->
示例返回体（JSON），包含 code/data/message 等
<!--/doc:keep:response-->

## 错误码
<!--doc:keep:errors-->
- 1001: <说明>
- 2001: <说明>
<!--/doc:keep:errors-->

## 副作用
<!--doc:keep:effects-->
- 写：<集合名>
- 读：<集合名>
<!--/doc:keep:effects-->

## 参考页面
<!--doc:auto:refs-->
- docs/pages/u_fu_jin_de_yi_yuan/spec.md
- docs/pages/u_shou_hu_home/spec.md
<!--/doc:auto:refs-->
